"""newsite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
# from django.views.generic import TemplateView
from django.views.static import serve
from newsite.settings import MEDIA_ROOT
import xadmin
from users.views import IndexView, ServiceAnnouncementView

urlpatterns = [

    url(r'^admin/', admin.site.urls),
    url(r'^xadmin/', xadmin.site.urls, name='xadmin'),
    url(r'^$', IndexView.as_view(), name='index'),
    url(r'^service$', ServiceAnnouncementView.as_view(), name='service_announcement'),
    url(r'^captcha/', include('captcha.urls'), name='captcha'),
    url(r'^media/(?P<path>.*)$', serve, {"document_root": MEDIA_ROOT}),
    # url(r'^static/(?P<path>.*)$', serve, {"document_root": STATIC_ROOT}),

    # 不同模块的url 有 用户登陆/电子书模块/个人中心模块/视频教程模块
    url(r'^users/', include('users.urls', namespace='login_system')),
    url(r'^ebooks/', include('ebooks.urls', namespace='ebooks_system')),
    url(r'^courses/', include('courses.urls', namespace='courses_system')),
]
