# _*_ coding: utf-8 _*_
import json

from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.views.generic.base import View
from .Forms import LoginForm, RegisterForm, ForgetForm, ResetForm,UserInfoForm,UploadImageForm
from django.contrib.auth.backends import ModelBackend
from users.models import UserProfile, EmailVerifyRecord
from django.db.models import Q
from django.contrib.auth.hashers import make_password
from utils.email_send import send_verify_email
from django.core.urlresolvers import reverse
from courses.models import Course
from ebooks.models import Ebook
from django.shortcuts import render_to_response
from django.contrib.auth.mixins import LoginRequiredMixin
from operations.models import UserCourse, UserEbook, UserMessage,UserFav
from pure_pagination import Paginator, EmptyPage, PageNotAnInteger
from .models import UserProfile, EmailVerifyRecord, BannerPic
from django.http import HttpResponseRedirect, HttpResponse


# re_define the authenticate func
class CustomBackend(ModelBackend):
    def authenticate(self, username=None, password=None, **kwargs):
        try:
            user = UserProfile.objects.get(Q(username=username) | Q(email=username))
            if user.check_password(password):
                return user
            else:
                return None
        except Exception as e:
            print(e)
            return None


# Create your views here.
class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')  # 进入登录页面

    def post(self, request):
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        login_form = LoginForm(request.POST)
        if login_form.is_valid():
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    user_name = user.username
                    return HttpResponseRedirect(reverse("index"))  # 登陆成功
                else:
                    return render(request, 'login.html', {'msg': "账号未激活"})
            else:
                return render(request, 'login.html', {'msg': "用户名或密码有误"})  # 登录失败
        else:
            return render(request, 'login.html', {'msg': '账号必填/密码至少五位数', 'login_form': login_form})  # 登录失败


class RegisterView(View):
    def get(self, request):
        register_form = RegisterForm()
        return render(request, 'register.html', {'register_form': register_form})  # 进入注册页面

    def post(self, request):
        register_form = RegisterForm(request.POST)
        if register_form.is_valid():
            email = request.POST.get('username', '')
            if UserProfile.objects.filter(email=email):
                return render(request, 'register.html', {'register_form': register_form, 'msg': '该邮箱已注册'})
            password = request.POST.get('password', '')
            user_profile = UserProfile()
            user_profile.username = email
            user_profile.email = email
            user_profile.is_active = False
            user_profile.password = make_password(password)
            user_profile.save()
            send_verify_email(email, 'register')
            return render(request, 'email_sended.html')
        else:
            return render(request, 'register.html', {'msg': '邮箱格式/则密码长度大于5/验证码', 'register_form': register_form})


class ForgetPwdView(View):
    def get(self, request):
        forget_form = ForgetForm()
        return render(request, 'forgetpwd.html', {'forget_form': forget_form})

    def post(self, request):
        forget_form = ForgetForm(request.POST)
        if forget_form.is_valid():
            email = request.POST.get('username', '')
            send_verify_email(email, 'forget')
            return render(request, "email_sended.html")
        else:
            return render(request, 'forgetpwd.html', {"forget_form": forget_form})


class ActiveUserView(View):
    def get(self, request, active_code):
        all_records = EmailVerifyRecord.objects.filter(code=active_code, send_type='register')
        if all_records:
            for record in all_records:
                email = record.email
                user = UserProfile.objects.get(email=email)
                user.is_active = True
                user.save()
                return render(request, 'login.html', {'msg': '账号验证通过，请登录！'})
        else:
            return render(request, '403.html')


class ResetPwdView(View):
    def get(self, request, reset_code):
        all_records = EmailVerifyRecord.objects.filter(code=reset_code, send_type='forget')
        if all_records:
            for record in all_records:
                email = record.email
                return render(request, 'password_reset.html', {'email': email})
        else:
            return render(request, '403.html')


class ModifyPwdView(View):
    def post(self, request):
        reset_form = ResetForm(request.POST)
        if reset_form.is_valid():
            pwd1 = request.POST.get('password1', '')
            pwd2 = request.POST.get('password1', '')
            email = request.POST.get('email', '')
            if pwd1 != pwd2:
                return render(request, 'password_reset.html', {'email': email, 'msg':'前后密码不一致'})
            user = UserProfile.objects.get(email=email)
            user.password = make_password(pwd1)
            user.save()
            return render(request, 'login.html', {'msg': '修改密码成功，请登录！'})
        else:
            email = request.POST.get('email', '')
            return render(request, 'password_reset.html', {'email': email, 'msg': '密码必填且大于5个字符',
                                                           'reset_form': reset_form})


class LogoutView(View):
    def get(self, request):
        logout(request)
        return HttpResponseRedirect(reverse("index"))


class IndexView(View):
    def get(self, request):
        banners = BannerPic.objects.order_by('-index')
        ebooks = Ebook.objects.order_by('click_nums')
        courses = Course.objects.order_by('click_nums')
        if ebooks.count() > 15:
            ebooks = ebooks[0:15]
        if courses.count() > 8:
            courses = courses[:8]
        banner_courses = courses[0:2]
        common_courses = courses[2:]
        bit = 0
        print(request.user)
        return render(request, 'index.html', {'ebooks': ebooks,
                                              'banner_courses': banner_courses,
                                              'common_courses': common_courses,
                                              'banners': banners,
                                              'bit': bit})


class ServiceAnnouncementView(View):
    def get(self, request):
        bit = 3
        return render(request, 'service_announcement.html', {'bit': bit})


def page_not_found(request):
    # 找不到页面时的处理方式
    response = render_to_response('404.html', {})
    response.status_code = 404
    return response


def page_error(request):
    # 服务器内部错误
    response = render_to_response('500.html', {})
    response.status_code = 500
    return response


def page_limited(request):
    # 权限问题，拒绝请求
    response = render_to_response('500.html', {})
    response.status_code = 403
    return response




#我的消息
class MyMessageView(LoginRequiredMixin, View):
    login_url = '/login/'
    redirect_field_name = 'next'

    def get(self, request):
        all_message = UserMessage.objects.filter(user= request.user.id)

        # 用户进入个人中心消息页面，清空未读消息记录
        all_unread_messages = UserMessage.objects.filter(user=request.user.id, has_read=False)
        for unread_message in all_unread_messages:
            unread_message.has_read = True
            unread_message.save()
        # 对课程机构进行分页
        # 尝试获取前台get请求传递过来的page参数
        # 如果是不合法的配置参数默认返回第一页
        try:
            page = request.GET.get('page', 1)
        except PageNotAnInteger:
            page = 1
        # 这里指从allorg中取五个出来，每页显示5个
        p = Paginator(all_message, 4)
        messages = p.page(page)
        return  render(request, "usercenter-message.html", {
        "messages":messages,
        })



class MyCourseView(LoginRequiredMixin, View):

    def get(self, request):
        favs = UserFav.objects.filter(user=request.user,fav_type=1)
        user_courses = [Course.objects.filter(id=fav.fav_id)[0] for fav in favs]
        print(user_courses[0].id)
        return render(request, "usercenter-mycourse.html", {
            "user_courses":user_courses,
        })
#我的电子书

class MyEbooks(LoginRequiredMixin, View):

    def get(self, request):
        user_Ebook = UserEbook.objects.filter(user=request.user)
        return render(request, "usercenter-mycourse.html", {
            "user_Ebooks":user_Ebook,
        })


class UserInfoView(LoginRequiredMixin, View):
    login_url = '/login/'
    redirect_field_name = 'next'

    def get(self, request):
        return render(request, "usercenter-info.html", {})

    def post(self, request):
        # 不像用户咨询是一个新的。需要指明instance。不然无法修改，而是新增用户
        user_info_form = UserInfoForm(request.POST, instance=request.user)
        if user_info_form.is_valid():
            user_info_form.save()
            return HttpResponse(
                '{"status":"success"}',
                content_type='application/json')
        else:
            # 通过json的dumps方法把字典转换为json字符串
            return HttpResponse(
                json.dumps(
                    user_info_form.errors),
                content_type='application/json')
# 用户上传图片的view:用于修改头像


class UploadImageView(LoginRequiredMixin, View):
    login_url = '/login/'
    redirect_field_name = 'next'

    def post(self, request):
        # 这时候用户上传的文件就已经被保存到imageform了 ，为modelform添加instance值直接保存
        image_form = UploadImageForm(
            request.POST, request.FILES, instance=request.user)
        if image_form.is_valid():
            image_form.save()
            # # 取出cleaned data中的值,一个dict
            # image = image_form.cleaned_data['image']
            # request.user.image = image
            # request.user.save()
            return HttpResponse(
                '{"status":"success"}',
                content_type='application/json')
        else:
            return HttpResponse(
                '{"status":"fail"}',
                content_type='application/json')