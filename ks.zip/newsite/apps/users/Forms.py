# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/2/23 14:56'
from django import forms
from captcha.fields import CaptchaField
from users.models import UserProfile

class LoginForm(forms.Form):
    username = forms.CharField(required=True)
    password = forms.CharField(required=True, min_length=5)


class RegisterForm(forms.Form):
    username = forms.EmailField(required=True)
    password = forms.CharField(required=True, min_length=5)
    captcha = CaptchaField(error_messages={'Invalid': {'验证码错误'}})


class ForgetForm(forms.Form):
    username = forms.CharField(required=True)
    captcha = CaptchaField(error_messages={'Invalid': {'验证码错误'}})


class ResetForm(forms.Form):
    password1 = forms.CharField(required=True, min_length=5)
    password2 = forms.CharField(required=True, min_length=5)


# 用于文件上传，修改头像
class UploadImageForm(forms.ModelForm):

    class Meta:
        model = UserProfile
        fields = ['image']

# 用于个人中心修改个人信息
class UserInfoForm(forms.ModelForm):

    class Meta:
        model = UserProfile
        fields = ['nick_name','gender','birthday','address','mobile']