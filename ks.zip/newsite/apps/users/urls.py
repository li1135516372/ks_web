#! /usr/bin/python
# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/3/22 9:54'


from django.conf.urls import url, include
from users.views import UserInfoView,LoginView, LogoutView, RegisterView, ActiveUserView, \
    ForgetPwdView, ResetPwdView, ModifyPwdView,MyMessageView,MyCourseView,MyEbooks,UploadImageView
urlpatterns = [
    url(r'^info/$', UserInfoView.as_view(), name="user_info"),
    url(r'^login/$', LoginView.as_view(), name='login'),
    url(r'^register/$', RegisterView.as_view(), name='register'),
    url(r'^activeOnKs/(?P<active_code>.*)/', ActiveUserView.as_view(), name='active'),
    url(r'^forgetPwd/', ForgetPwdView.as_view(), name='forgetPwd'),
    url(r'^resetPassword/(?P<reset_code>.*)/', ResetPwdView.as_view(), name='resetPwd'),
    url(r'^modifyPwd/', ModifyPwdView.as_view(), name='modifyPwd'),
    url(r'^logout/$', LogoutView.as_view(), name='logout'),
    url(r'^my_message/$', MyMessageView.as_view(), name='my_message'),
    url(r'^mycourse/$', MyCourseView.as_view(), name='mycourse'),
    url(r'^MyEbooks/$', MyEbooks.as_view(), name='MyEbooks'),
    url(r'^UploadImageView/$', UploadImageView.as_view(), name='UploadImageView'),
]

handler404 = 'users.views.page_not_found'
handler403 = 'users.views.page_limited'
handler500 = 'users.views.page_error'
