from django.db import models
from datetime import datetime
from courses.models import Course
from users.models import UserProfile
from ebooks.models import Ebook


# Create your models here.
class CourseComment(models.Model):
    user = models.ForeignKey(UserProfile, verbose_name='用户')
    course = models.ForeignKey(Course, verbose_name='课程')
    comments = models.CharField(max_length=500, verbose_name='评论')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='添加时间')

    class Meta:
        verbose_name = '课程评论'
        verbose_name_plural = verbose_name


class UserFav(models.Model):
    user = models.ForeignKey(UserProfile, verbose_name='姓名')
    fav_id = models.IntegerField(default=0, verbose_name='数据id')
    fav_type = models.IntegerField(choices=((1, '视频教程'), (2, '电子书籍')))
    add_time = models.DateTimeField(default=datetime.now, verbose_name='添加时间')

    class Meta:
        verbose_name = '用户收藏'
        verbose_name_plural = verbose_name


class UserMessage(models.Model):
    user = models.ForeignKey(UserProfile, verbose_name='姓名')
    message = models.CharField(max_length=500, verbose_name='消息内容')
    has_read = models.BooleanField(default=False, verbose_name='是否已读')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='添加时间')

    class Meta:
        verbose_name = '用户消息'
        verbose_name_plural = verbose_name


class UserCourse(models.Model):
    user = models.ForeignKey(UserProfile, verbose_name='姓名')
    course = models.ForeignKey(Course, verbose_name='课程')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='添加时间')

    class Meta:
        verbose_name = '用户课程'
        verbose_name_plural = verbose_name


class UserEbook(models.Model):
    user = models.ForeignKey(UserProfile, verbose_name='用户')
    ebook = models.ForeignKey(Ebook, verbose_name='书籍')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='添加时间')

    class Meta:
        verbose_name = '用户书籍'
        verbose_name_plural = verbose_name


class EbookComment(models.Model):
    user = models.ForeignKey(UserProfile, verbose_name='用户')
    ebook = models.ForeignKey(Ebook, verbose_name='书籍')
    comments = models.CharField(max_length=500, verbose_name='评论')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='添加时间')

    class Meta:
        verbose_name = '书籍评论'
        verbose_name_plural = verbose_name
