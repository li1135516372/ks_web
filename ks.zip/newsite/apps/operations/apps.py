from django.apps import AppConfig


class OperationsConfig(AppConfig):
    name = 'operations'
    verbose_name = '用户行为管理'
