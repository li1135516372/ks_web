#! /usr/bin/python
# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/3/30 21:19'
from .models import CourseComment, UserFav, UserCourse, UserMessage, EbookComment, UserEbook
import xadmin


class CourseCommentAdmin(object):
    list_display = ['user', 'course', 'comments', 'add_time']
    search_fields = ['user', 'course', 'comments']
    list_filter = ['add_time']


class UserFavAdmin(object):
    list_display = ['user', 'fav_id', 'fav_type', 'add_time']
    search_fields = ['user', 'fav_id', 'fav_type', 'add_time']
    list_filter = ['user', 'fav_id', 'fav_type', 'add_time']


class UserMessageAdmin(object):
    list_display = ['user', 'message', 'has_read', 'add_time']
    search_fields = ['user', 'message', 'has_read', 'add_time']
    list_filter = ['user', 'message', 'has_read', 'add_time']


class UserCourseAdmin(object):
    list_display = ['user', 'course', 'add_time']
    search_fields = ['user', 'course', 'add_time']
    list_filter = ['user', 'course', 'add_time']


class EbookCommentAdmin(object):
    list_display = ['user', 'ebook', 'comments', 'add_time']
    search_fields = ['user', 'ebook', 'comments']
    list_filter = ['add_time']


class UserEbookAdmin(object):
    list_display = ['user', 'ebook', 'add_time']
    search_fields = ['user', 'ebook']
    list_filter = ['add_time']


xadmin.site.register(CourseComment, CourseCommentAdmin)
xadmin.site.register(UserFav, UserFavAdmin)
xadmin.site.register(UserMessage, UserMessageAdmin)
xadmin.site.register(UserCourse, UserCourseAdmin)
xadmin.site.register(EbookComment, EbookCommentAdmin)
xadmin.site.register(UserEbook, UserEbookAdmin)
