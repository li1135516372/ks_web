from django.shortcuts import render
from django.views.generic.base import View
from .models import Course, Chapter, CourseResource, Video
from operations.models import UserFav
from pure_pagination import Paginator, PageNotAnInteger
from django.http import HttpResponse

bit = 1


# Create your views here.
class CourseHomeView(View):
    def get(self, request):
        key_word = request.GET.get('sort', '')
        if key_word:
            try:
                courses = Course.objects.all().order_by('-'+key_word)
            except Exception as e:
                print("**", e)
                courses = Course.objects.all()
        else:
            courses = Course.objects.all()
        hot_courses = Course.objects.order_by("click_nums")[:3]

        try:
            page = request.GET.get('page', 1)
        except PageNotAnInteger:
            page = 1
        course_page = Paginator(courses, 6, request=request)
        course_list = course_page.page(page)
        return render(request, 'course_list.html', {'hot_courses': hot_courses,
                                                    'course_list': course_list,
                                                    'key_word': key_word,
                                                    'bit': bit})


class CourseDetailView(View):
    def get(self, request, course_id):
        try:
            course = Course.objects.get(id=course_id)
        except:
            return render(request, '403.html', {})
        course.click_nums += 1
        course.save()
        hot_course = Course.objects.order_by('click_nums')[0]
        has_fav_record1 = False
        has_fav_record2 = False
        if request.user.is_authenticated():
            fav_record1 = UserFav.objects.filter(user=request.user, fav_id=course.id, fav_type=1)
            fav_record2 = UserFav.objects.filter(user=request.user, fav_id=hot_course.id, fav_type=1)
            if fav_record1:
                has_fav_record1 = True
            if fav_record2:
                has_fav_record2 = True
        related_course = Course.objects.filter(category=course.category)
        if related_course.count() > 2:
            related_course = related_course[:2]
        return render(request, 'course-detail.html', {'course': course, 'hot_course': hot_course,
                                                      'related_courses': related_course,
                                                      'has_fav_record1': has_fav_record1,
                                                      'has_fav_record2': has_fav_record2,
                                                      'bit': bit})


class CourseAddFavView(View):
    def post(self, request):
        fav_id = request.POST.get('fav_id', 0)
        fav_type = request.POST.get('fav_type', 0)

        if not request.user.is_authenticated():
            return HttpResponse('{"status":"fail", "msg":"用户未登陆"}', content_type='application/json')

        fav_records = UserFav.objects.filter(user=request.user, fav_id=fav_id, fav_type=fav_type)
        course = Course.objects.get(id=fav_id)
        if fav_records:
            print('bushou')
            course.fav_nums -= 1
            course.save()
            fav_records.delete()
            return HttpResponse('{"status":"success", "msg":"收藏"}', content_type='application/json')
        else:
            print('shou')
            new_record = UserFav()
            new_record.user = request.user
            new_record.fav_type = fav_type
            new_record.fav_id = fav_id
            new_record.save()
            course.fav_nums += 1
            course.save()
            return HttpResponse('{"status":"success", "msg":"取消收藏"}', content_type='application/json')


class CourseChaptersView(View):
    def get(self, request, course_id):
        try:
            course = Course.objects.get(id=course_id)
        except:
            return render(request, '403.html', {})
        # 反方向取数据失败
        # chapters = course.Chapter_set().all()
        course.students += 1
        course.save()
        chapters = Chapter.objects.filter(course=course)
        resourses = CourseResource.objects.filter(course=course)
        may_likes = Course.objects.order_by('students')
        if may_likes.count() > 5:
            may_likes = may_likes[:5]
        return render(request, 'course-chapters.html', {'course': course, 'chapters': chapters,
                                                        'resourses': resourses,
                                                        'may_likes': may_likes,
                                                        'bit': bit})


class CourseVideoView(View):
    def get(self,  request, video_id):
        try:
            video = Video.objects.get(id=video_id)
        except:
            return render(request, '404.html', {})
        course = video.chapter.course
        chapters = course.chapter_set.all()
        resourses = course.courseresource_set.all()
        may_likes = Course.objects.order_by('-students')
        if may_likes.count() > 5:
            may_likes = may_likes[:5]
        return render(request, 'course-video.html', {"video": video, 'course': course,
                                                     'chapters': chapters, 'resourses': resourses,
                                                     'may_likes': may_likes})

