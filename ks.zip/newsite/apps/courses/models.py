from django.db import models
from datetime import datetime


# Create your models here.
class Course(models.Model):
    name = models.CharField(max_length=30, verbose_name='课程名称')
    description = models.CharField(max_length=300, verbose_name='课程描述')
    category = models.CharField(max_length=50, choices=(('Python', 'Python'), ('R', 'R'),
                                                        ('Java', 'Java'), ('C#', "C#"),
                                                        ('C++', 'C++'), ('C', 'C')), verbose_name='课程类别')
    detail = models.TextField(verbose_name='课程详情')
    image = models.ImageField(verbose_name='封面图', upload_to='course/logos')
    degree = models.CharField(max_length=2, choices=(('cj', '初级'), ('zj', '中级'), ('gj', '高级')))
    learn_times = models.IntegerField(verbose_name='学习时长（min）', default=0)
    students = models.IntegerField(default=0, verbose_name='学习人数')
    fav_nums = models.IntegerField(default=0, verbose_name='收藏人数')
    click_nums = models.IntegerField(default=0, verbose_name='点击次数')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='课程上线时间')
    priority_index = models.IntegerField(default=0, verbose_name='排序索引')

    class Meta:
        verbose_name = '课程'
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.name

    def __str__(self):
        return self.name

    def get_chapters_num(self):
        return self.chapter_set.all().count()


class Chapter(models.Model):
    course = models.ForeignKey(Course, verbose_name='所属课程')
    chapter_name = models.CharField(max_length=50, verbose_name='章节名')
    index = models.IntegerField(default=0, verbose_name='排序索引')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='章节添加时间')

    class Meta:
        verbose_name = '章节信息'
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.chapter_name

    def __str__(self):
        return self.chapter_name

    def get_videos(self):
        return self.video_set.all()


class Video(models.Model):
    chapter = models.ForeignKey(Chapter, verbose_name='所属章节')
    video_name = models.CharField(max_length=30, verbose_name='视频名称')
    index = models.IntegerField(default=0, verbose_name='排序索引')
    download = models.FileField(verbose_name='视频下载', upload_to='course/video/', blank=True, null=True)
    add_time = models.DateTimeField(default=datetime.now, verbose_name='视频添加时间')

    class Meta:
        verbose_name = '视频信息'
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.video_name

    def __str__(self):
        return self.video_name


class CourseResource(models.Model):
    course = models.ForeignKey(Course, verbose_name='课程名称')
    CourseResource_name = models.CharField(max_length=100, verbose_name='课程资源名称')
    download = models.FileField(verbose_name='课程资源下载', upload_to='course/resource/', blank=True, null=True)
    index = models.IntegerField(default=0, verbose_name='排序索引')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='资源添加时间')

    class Meta:
        verbose_name = '资源信息'
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.CourseResource_name

    def __str__(self):
        return self.CourseResource_name

