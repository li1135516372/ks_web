#! /usr/bin/python
# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/3/22 21:11'

import xadmin
from .models import Course, Chapter, Video, CourseResource


class CourseAdmin(object):
    list_display = ['name', 'category', 'description', 'detail', 'learn_times', 'degree', 'students', 'fav_nums',
                    'image', 'click_nums', 'add_time']
    list_filter = ['name', 'category', 'description', 'detail', 'learn_times', 'students', 'fav_nums',
                   'image', 'click_nums', 'add_time']
    search_field = ['name', 'category', 'description', 'detail', 'learn_times',
                    'image']


class ChapterAdmin(object):
    list_display = ['course', 'chapter_name', 'add_time']
    search_field = ['course', 'chapter_name']
    list_filter = ['course', 'chapter_name', 'add_time']


class VideoAdmin(object):
    list_display = ['chapter', 'video_name', 'add_time']
    list_filter = ['chapter', 'video_name', 'add_time']
    search_field = ['chapter', 'video_name']


class CourseResourceAdmin(object):
    list_display = ['course', 'CourseResource_name', 'download', 'add_time']
    list_filter = ['course', 'CourseResource_name', 'download', 'add_time']
    search_field = ['course', 'CourseResource_name', 'download']


xadmin.site.register(CourseResource, CourseResourceAdmin)
xadmin.site.register(Video, VideoAdmin)
xadmin.site.register(Chapter, ChapterAdmin)
xadmin.site.register(Course, CourseAdmin)
