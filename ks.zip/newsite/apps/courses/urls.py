#! /usr/bin/python
# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/3/26 21:45'


from django.conf.urls import url
from .views import CourseHomeView, CourseDetailView, CourseAddFavView, CourseChaptersView,CourseVideoView


urlpatterns = [
    # 本模块 url 配置
    url(r'^index/$', CourseHomeView.as_view(), name='courses_home'),
    url(r'^detail/(?P<course_id>\d+)$', CourseDetailView.as_view(), name='courses_detail'),
    url(r'^fav/$', CourseAddFavView.as_view(), name='add_fav'),
    url(r'^chapters/(?P<course_id>\d+)$', CourseChaptersView.as_view(), name='courses_chapter'),
    url(r'^video/(?P<video_id>\d+)$', CourseVideoView.as_view(), name='courses_video'),
]
