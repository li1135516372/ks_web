from django.db import models
from datetime import datetime
# Create your models here.


class Ebook(models.Model):
    name = models.CharField(max_length=30, verbose_name='书籍名称')
    description = models.CharField(max_length=300, verbose_name='书籍描述')
    detail = models.TextField(verbose_name='书籍详情')
    category = models.CharField(max_length=50, choices=(('Python', 'Python'), ('R', 'R'),
                                                        ('Java', 'Java'), ('C#', "C#"),
                                                        ('C++', 'C++'),('C', 'C')), verbose_name='课程类别')
    degree = models.CharField(max_length=2, default='cj', choices=(('cj', '初级'), ('zj', '中级'), ('gj', '高级')))
    fav_nums = models.IntegerField(default=0, verbose_name='收藏人数')
    image = models.ImageField(verbose_name='封面图', upload_to='ebook/logo')
    click_nums = models.IntegerField(default=0, verbose_name='点击次数')
    add_time = models.DateTimeField(default=datetime.now, verbose_name='书籍上线时间')
    free_or_not = models.CharField(max_length=2, choices=(('mf', '免费'), ('sf', '书费')))
    download = models.FileField(verbose_name='下载', upload_to='ebook/resource/')
    download_nums = models.IntegerField(default=0, verbose_name='收藏人数')
    priority_index = models.IntegerField(default=0, verbose_name='排序索引')

    class Meta:
        verbose_name = '电子书籍'
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.name

    def __str__(self):
        return self.name