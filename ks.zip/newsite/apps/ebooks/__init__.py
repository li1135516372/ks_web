default_app_config = 'ebooks.apps.EbooksConfig'
