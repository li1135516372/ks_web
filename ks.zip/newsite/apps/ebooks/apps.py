# _*_ coding: utf-8 _*_
from django.apps import AppConfig


class EbooksConfig(AppConfig):
    name = 'ebooks'
    verbose_name = '电子书籍管理'
