#! /usr/bin/python
# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/3/22 19:44'

from django.conf.urls import url
from .views import EbooksHomeView, EbookDetailView, EbookAddFavView, EbookReadView

urlpatterns = [
    # 本模块 url 配置
    url(r'^index/$', EbooksHomeView.as_view(), name='ebooks_home'),
    url(r'^detail/(?P<book_id>\d+)$', EbookDetailView.as_view(), name='ebooks_detail'),
    url(r'^read/(?P<book_id>\d+)$', EbookReadView.as_view(), name='ebooks_read'),
    url(r'^fav/$', EbookAddFavView.as_view(), name='add_fav'),

]
