from django.shortcuts import render
from django.views.generic.base import View
from .models import Ebook
from operations.models import UserFav
from pure_pagination import Paginator, PageNotAnInteger
from django.http import HttpResponse

bit = 2


# Create your views here.
class EbooksHomeView(View):
    def get(self, request):
        key_word = request.GET.get('category', '')
        hot_books = Ebook.objects.all().order_by('-fav_nums')
        if hot_books.count() > 3:
            hot_books = hot_books[:3]
        if key_word == '':
            books = Ebook.objects.all()
        else:
            books = Ebook.objects.filter(category=key_word)
        sort_key = request.GET.get('sort', '')
        if sort_key:
            if sort_key == 'add_time':
                books = books.order_by('-add_time')
            elif sort_key == 'download_nums':
                books = books.order_by('-download_nums')
            elif sort_key == 'fav_nums':
                books = books.order_by('-fav_nums')
        book_num = books.count()

        try:
            page = request.GET.get('page', 1)
        except PageNotAnInteger:
            page = 1
        book_page = Paginator(books, 4, request=request)
        book_list = book_page.page(page)
        return render(request, 'ebooks_home.html', {'book_list': book_list,
                                                    'book_num': book_num,
                                                    'key_word': key_word,
                                                    'hot_books': hot_books,
                                                    'sort_key': sort_key,
                                                    'bit': bit})


class EbookDetailView(View):
    def get(self, request, book_id):
        book = Ebook.objects.get(id=int(book_id))
        book.click_nums += 1
        book.save()
        hot_books = Ebook.objects.all().order_by('-fav_nums')
        if hot_books.count() > 1:
            hot_books = hot_books[0]
        has_fav_record1 = False
        has_fav_record2 = False
        if request.user.is_authenticated():
            fav_record1 = UserFav.objects.filter(user=request.user, fav_id=book.id, fav_type=2)
            fav_record2 = UserFav.objects.filter(user=request.user, fav_id=hot_books.id, fav_type=2)
            if fav_record1:
                has_fav_record1 = True
            if fav_record2:
                has_fav_record2 = True

        related_books = Ebook.objects.filter(category=book.category)
        return render(request, 'ebooks_detail.html', {'book': book, 'hot_books': hot_books,
                                                      'related_books': related_books,
                                                      'has_fav_record1': has_fav_record1,
                                                      'has_fav_record2': has_fav_record2,
                                                      'bit': bit})


class EbookAddFavView(View):
    def post(self, request):
        fav_id = request.POST.get('fav_id', 0)
        fav_type = request.POST.get('fav_type', 0)

        if not request.user.is_authenticated():
            return HttpResponse('{"status":"fail", "msg":"用户未登陆"}', content_type='application/json')

        fav_records = UserFav.objects.filter(user=request.user, fav_id=fav_id, fav_type=fav_type)
        ebook = Ebook.objects.get(id=fav_id)
        if fav_records:
            ebook.fav_nums -= 1
            ebook.save()
            fav_records.delete()
            return HttpResponse('{"status":"success", "msg":"收藏"}', content_type='application/json')
        else:
            new_record = UserFav()
            new_record.user = request.user
            new_record.fav_type = fav_type
            new_record.fav_id = fav_id
            new_record.save()
            ebook.fav_nums += 1
            ebook.save()
            return HttpResponse('{"status":"success", "msg":"取消收藏"}', content_type='application/json')


class EbookReadView(View):
    pass

