#! /usr/bin/python
# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/3/22 20:46'

from .models import Ebook
import xadmin


class EbookAdmin(object):
    list_display = ['name', 'category', 'description', 'detail', 'image', 'free_or_not', 'priority_index', 'add_time']
    search_fields = ['name', 'category', 'description', 'detail', 'free_or_not', 'add_time']
    list_filter = ['name', 'category', 'description', 'detail', 'free_or_not', 'add_time']


xadmin.site.register(Ebook, EbookAdmin)
