# _*_ coding: utf-8 _*_
__author__ = 'Jeffery'
__date__ = '2018/2/23 17:23'
from random import Random

from django.core.mail import send_mail

from newsite.settings import EMAIL_FROM
from users.models import EmailVerifyRecord


def generate_random_str(length=16):
    chars = 'QWERTYUIOPASDFGHJKLZXCVBNMmnbvcxzlkjhgfdsapoiuytrewq0987654321'
    random_str = ''
    random = Random()
    for i in range(length):
        random_str += chars[random.randint(0, len(chars)-1)]
    return random_str


def send_verify_email(email, send_type='register'):
    email_verify = EmailVerifyRecord()
    email_verify.code = generate_random_str()
    email_verify.email = email
    email_verify.send_type = send_type

    email_title = ''
    email_body = ''
    if send_type == 'register':
        email_title = '个人在线网注册激活链接'
        email_body = '请点击下面的链接激活您的注册账号：http://127.0.0.1:8000/users/activeOnKs/'+email_verify.code
    elif send_type == 'forget':
        email_title = '个人在线网修改链接'
        email_body = '请点击下面的链接修改您的账号密码：http://127.0.0.1:8000/users/resetPassword/'+email_verify.code

    email_status = send_mail(email_title, email_body, EMAIL_FROM, [email])

    if email_status:
        email_verify.save()
    else:
        print('***邮件发送失败')
